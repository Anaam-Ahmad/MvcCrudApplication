﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_Crud.Models;

namespace MVC_Crud.Controllers
{
    public class ProductController : Controller
    {
        DatabaseContext db = new DatabaseContext();
        // GET: Product
        public ActionResult GetProduct()
        {
            if(ModelState.IsValid)
            {
                var product = db.Product.ToList();
                return View(product);
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public ActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddProduct(Product product)
        {
            TryUpdateModel<Product>(product);
            if (ModelState.IsValid)
            {
                db.Product.Add(product);
                db.SaveChanges();
                return RedirectToAction("GetProduct", "Product");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public ActionResult UpdateProduct(int id)
        {
            return View(db.Product.Find(id));
        }

        [HttpPost]
        public ActionResult UpdateProduct(Product product)
        {
            Product prod = db.Product.Where(p => p.id == product.id).SingleOrDefault();
            if (ModelState.IsValid)
            {
                db.Entry(prod).CurrentValues.SetValues(product);
                db.SaveChanges();
                return RedirectToAction("GetProduct", "Product");
            }
            else
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            db.Product.Remove(db.Product.Find(id));
            db.SaveChanges();
            return RedirectToAction("GetProduct", "Product");
        }
    }
}