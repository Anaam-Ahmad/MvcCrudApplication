﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_Crud.Models
{
    public class Product
    {
        [Key]
        [Required]
        public int id { get; set; }
        [Required]
        public string ProductName { get; set; }
        [Required]
        public string Price { get; set; }
        public string UPC { get; set; }
    }
}