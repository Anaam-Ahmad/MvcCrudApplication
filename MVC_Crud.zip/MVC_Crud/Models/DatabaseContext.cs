﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace MVC_Crud.Models
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("name = connectionString")
        { }

        public DbSet<Product> Product { get; set; }
    }
}